"""ansys.api.fluent.v0 python protocol version"""
__version__ = '0.0.1'  # major.minor.patch
