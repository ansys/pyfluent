# Copyright (C) 2021 - 2026 Synopsys, Inc. and ANSYS, Inc. All rights reserved.
# SPDX-License-Identifier: MIT
#
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

""".. _frozen_rotor_simulation:

Impeller-Volute simulation using the Frozen Rotor Approach
----------------------------------------------------------------------
"""

################################################################################################################
# Objective
# ==============================================================================================================
#
# This example demonstrates how to set up a CFD simulation of an impeller and volute using
# the frozen rotor approach. The frozen rotor approach is a technique used in computational
# fluid dynamics (CFD) to simulate the flow around rotating machinery, such as pumps,
# turbines, and compressors. In this approach, the rotor is treated as a stationary
# component, while the surrounding fluid is allowed to move. This allows for a more
# efficient simulation of the flow field, as the rotor's motion does not need to be
# explicitly modeled. The frozen rotor approach is particularly useful for simulating
# steady-state flows, where the rotor's motion is constant.
# By using this approach, engineers can obtain accurate predictions of the
# flow field and performance characteristics of rotating machinery without the need for
# complex and computationally expensive simulations.
#
#
# .. image:: ../../_static/pump-volute-geom.png
#    :align: center
#    :alt: Pump Volute Geometry View

################################################################################################################
# Outline
# ==============================================================================================================
#
# The example demonstrates the following:
#
# * Overview & Problem description
# * Launching Fluent in solver mode.
# * Downloading a mesh files from the examples repository.
# * Initial setup
# * Mesh configuration
# * Model selection & Material definition
# * Defining cell zone conditions & boundary conditions
# * Turbomachinery configuration
# * Solver settings
# * Report definitions
# * Initialization
# * Running the simulation
# * Post-processing the results
# * Visualizing the results
# * Saving the case file
# * Closing the solver

# .. note::
# This example has been verified and validated using Ansys Fluent 2025 R2.
# It requires Ansys Fluent version 2025 R2 or later, as it uses features that are not available in
# earlier versions.

################################################################################################################
# Import required libraries/modules
# ==============================================================================================================
import math
import os

import ansys.fluent.core as pyfluent
from ansys.fluent.core import examples

################################################################################################################
# Download the mesh file
# ==============================================================================================================

# Download the mesh file from the examples repository
# Impeller and volute mesh files
impeller_mesh = examples.download_file(
    "impeller.msh.h5",
    "pyfluent/examples/pump-volute",
    save_path=os.getcwd(),
)

volute_mesh = examples.download_file(
    "volute.msh.h5",
    "pyfluent/examples/pump-volute",
    save_path=os.getcwd(),
)

################################################################################################################
# Define Constants
# ==============================================================================================================

density_water = 998.2  # kg/m^3
viscosity_water = 0.001002  # kg/(m.s)
g = 9.81  # m/s^2
# Impeller speed
impeller_speed = 1450  # rpm
# Convert to rad/s
impeller_speed_rad = impeller_speed * 2 * math.pi / 60  # rad/s

################################################################################################################
# Launch Fluent with solver mode and print Fluent version
# ==============================================================================================================

solver_session = pyfluent.launch_fluent(
    mode="solver",
    processor_count=4,
    cleanup_on_exit=True,
)
print(solver_session.get_fluent_version())


################################################################################################################
# Read, append the mesh files
# ==============================================================================================================

# Read Impeller mesh file
solver_session.settings.file.read_mesh(file_name=impeller_mesh)
# Append Volute mesh file
solver_session.settings.mesh.modify_zones.append_mesh(file_name=volute_mesh)

################################################################################################################
# Display the mesh
# ==============================================================================================================

# Access the graphics object
graphics = solver_session.settings.results.graphics

# Create a mesh object and configure its settings
mesh_object = solver_session.settings.results.graphics.mesh.create(name="mesh-1")
mesh_object.surfaces_list.set_state(
    [
        "inlet",
        "mass-flow-inlet-11",
        "interface-impeller-outlet",
        "interface-volute-inlet",
        "blade",
        "impeller-hub",
        "impeller-shroud",
        "inblock-hub",
        "inblock-shroud",
        "volute-inlet-wall",
        "volute-wall",
    ]
)
mesh_object.options.edges.set_state(True)


# Set the hardcopy format for saving the image
graphics.picture.driver_options.hardcopy_format.set_state("png")

graphics.views.restore_view(view_name="front")
mesh_object.display()
graphics.views.auto_scale()
graphics.picture.save_picture(
    file_name="pump-volute-mesh.png",
)


# %%
# .. image:: ../../_static/pump-volute-mesh.png
#    :align: center
#    :width: 650px
#    :height: 400px
#    :alt: Pump Volute Mesh

################################################################################################################
# Set the unit for angular velocity, rad/s to rev/min
# ==============================================================================================================

solver_session.settings.setup.general.units.set_units(
    quantity="angular-velocity", units_name="rev/min"
)

################################################################################################################
# Define the Viscous Model
# ==============================================================================================================

# Models setting
viscous = solver_session.settings.setup.models.viscous
viscous = solver_session.settings.setup.models.viscous
viscous.model.set_state("k-omega")
viscous.k_omega_model.set_state("sst")

################################################################################################################
# Define Materials
# ==============================================================================================================
solver_session.settings.setup.materials.database.copy_by_name(
    type="fluid", name="water-liquid"
)

################################################################################################################
# Define Cell Zone Conditions
# ==============================================================================================================

impeller_cell_zone = solver_session.settings.setup.cell_zone_conditions.fluid[
    "impeller"
]
impeller_cell_zone.general.material.set_state("water-liquid")

impeller_cell_zone.reference_frame.reference_frame_axis_origin.set_state([0, 0, 0])
impeller_cell_zone.reference_frame.reference_frame_axis_direction.set_state([0, 0, 1])
impeller_cell_zone.reference_frame.frame_motion.set_state(True)

# impeller rotation
impeller_cell_zone.reference_frame.mrf_omega.value.set_state(impeller_speed_rad)


# Volute Cell Zone Conditions
volute_cell_zone = solver_session.settings.setup.cell_zone_conditions.fluid["volute"]
volute_cell_zone.general.material.set_state("water-liquid")


# Boundary Conditions
# impeller hub
impeller_hub = solver_session.settings.setup.boundary_conditions.wall[
    "impeller-hub"
].momentum
impeller_hub.wall_motion.set_state("Moving Wall")
impeller_hub.relative.set_state("Relative to Adjacent Cell Zone")
impeller_hub.velocity_spec.set_state("Rotational")

#  inblock-shroud

inblock_shroud = solver_session.settings.setup.boundary_conditions.wall[
    "inblock-shroud"
].momentum
inblock_shroud.wall_motion.set_state("Moving Wall")
inblock_shroud.relative.set_state("Absolute")
inblock_shroud.velocity_spec.set_state("Rotational")

################################################################################################################
# Define Boundary Conditions
# ==============================================================================================================

# Inlet Boundary Condition
pressure_inlet = solver_session.settings.setup.boundary_conditions.pressure_inlet[
    "inlet"
]
pressure_inlet.momentum.supersonic_or_initial_gauge_pressure.value.set_state(-100)

# It seems, need to change the boundary condition to mass flow outlet
solver_session.settings.setup.boundary_conditions.set_zone_type(
    zone_list=["mass-flow-inlet-11"], new_type="mass-flow-outlet"
)
# Outlet Boundary Condition

mass_flow_outlet = solver_session.settings.setup.boundary_conditions.mass_flow_outlet[
    "mass-flow-inlet-11"
]
mass_flow_outlet.momentum.mass_flow_rate.value.set_state(90)  # kg/s


# Create a turbo interfaces
# enable the turbo models
solver_session.settings.setup.turbo_models.enabled.set_state(True)

impeller_volute_interface = (
    solver_session.settings.setup.mesh_interfaces.turbo_create.create(
        adjacent_cell_zone_1="impeller",
        adjacent_cell_zone_2="volute",
        mesh_interface_name="imp-volute-interface",
        turbo_choice="No-Pitch-Scale",
        zone1="interface-impeller-outlet",
        zone2="interface-volute-inlet",
    )
)

################################################################################################################
# Define Solver Settings
# ==============================================================================================================
methods = solver_session.settings.solution.methods
methods.spatial_discretization.gradient_scheme.set_state("green-gauss-node-based")
methods.high_order_term_relaxation.enable.set_state(True)

################################################################################################################
# Define Named Expressions
# ==============================================================================================================

pump_head = solver_session.settings.setup.named_expressions.create("head")
pump_head.definition.set_state("(({p-out} - {p-in}) / (998.2 [kg/m^3] * 9.81[m/s^2]))")
pump_head.output_parameter.set_state(True)


################################################################################################################
# Define Report Definitions
# ==============================================================================================================

# Create a report definition
# p-out
outlet_pressure_report_def = (
    solver_session.settings.solution.report_definitions.surface.create("p-out")
)
outlet_pressure_report_def.report_type.set_state("surface-massavg")
outlet_pressure_report_def.surface_names.set_state(["mass-flow-inlet-11"])
outlet_pressure_report_def.field.set_state("total-pressure")
outlet_pressure_report_def.per_surface.set_state(False)

outlet_pressure_report_plot = (
    solver_session.settings.solution.monitor.report_plots.create("p-out-rplot")
)
outlet_pressure_report_plot.report_defs.set_state("p-out")

outlet_pressure_report_file = (
    solver_session.settings.solution.monitor.report_files.create("p-out-rfile")
)
outlet_pressure_report_file.report_defs.set_state("p-out")

# p-in
inlet_pressure_report_def = (
    solver_session.settings.solution.report_definitions.surface.create("p-in")
)
inlet_pressure_report_def.report_type.set_state("surface-massavg")
inlet_pressure_report_def.surface_names.set_state(["inlet"])
inlet_pressure_report_def.field.set_state("total-pressure")
inlet_pressure_report_def.per_surface.set_state(False)


# Pump Head
pump_head_report_def = (
    solver_session.settings.solution.report_definitions.single_valued_expression.create(
        "pump-head"
    )
)

pump_head_report_def.definition.set_state("head")

# report plot
pump_head_report_plot = solver_session.settings.solution.monitor.report_plots.create(
    "pump-head-rplot"
)
pump_head_report_plot.report_defs.set_state("pump-head")

# report file
pump_head_report_file = solver_session.settings.solution.monitor.report_files.create(
    "pump-head-rfile"
)
pump_head_report_file.report_defs.set_state("pump-head")

# p-blade
blade_pressure_report_def = (
    solver_session.settings.solution.report_definitions.surface.create("p-blade")
)
blade_pressure_report_def.report_type.set_state("surface-massavg")
blade_pressure_report_def.surface_names.set_state(["blade"])
blade_pressure_report_def.field.set_state("pressure")
blade_pressure_report_def.per_surface.set_state(False)


################################################################################################################
# Initialization and run solver
# ==============================================================================================================
initialization = solver_session.settings.solution.initialization
initialization.reference_frame.set_state("absolute")
initialization.hybrid_init_options.general_settings.initialization_options.initial_pressure.set_state(
    (True)
)
initialization.hybrid_initialize()

# Run calculation settings
run_calculation = solver_session.settings.solution.run_calculation
run_calculation.pseudo_time_settings.time_step_method.time_step_size_scale_factor.set_state(
    10
)
run_calculation.iter_count.set_state(200)

# Write the case file
solver_session.settings.file.write(
    file_type="case", file_name="pump_voulte_setup.cas.h5"
)
# Run the calculation
run_calculation.calculate()

################################################################################################################
# Post-Processing Workflow
# ==============================================================================================================

# Create a mid-plane surface at z = -0.015 m
z_mid_plane = solver_session.settings.results.surfaces.plane_surface.create(
    name="z_mid_plane"
)
z_mid_plane.method.set_state("xy-plane")
z_mid_plane.z.set_state(-0.015)
z_mid_plane.display()

# Define the contour for static pressure
pressure_contour = solver_session.settings.results.graphics.contour.create(
    name="static-pressure-contour"
)
pressure_contour.field.set_state("pressure")
pressure_contour.surfaces_list.set_state(["z_mid_plane"])

# Display the contour and save the image

graphics.views.restore_view(view_name="front")
pressure_contour.display()
graphics.views.auto_scale()
graphics.picture.save_picture(file_name="static-pressure-contour.png")


# %%
# .. image:: ../../_static/static-pressure-contour.png
#    :align: center
#    :alt: Static Pressure Contour

################################################################################################################
# Save the case file
# ==============================================================================================================
solver_session.settings.file.write(
    file_type="case-data", file_name="pump_volute_setup_solved.cas.h5"
)

################################################################################################################
# Close the session
# ==============================================================================================================
solver_session.exit()

################################################################################################################
# References
# ==============================================================================================================
#
# [1] Ansys Fluent User's Guide, Release 2025R1

# sphinx_gallery_thumbnail_path = '_static/static-pressure-contour.png'
